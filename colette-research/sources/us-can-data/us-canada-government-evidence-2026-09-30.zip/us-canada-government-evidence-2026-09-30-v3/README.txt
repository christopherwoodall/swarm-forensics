Evidence accompanying https://transluce.org/us-canada-gov

Folders are organized according to the sections of the post. Source URLs are included in the data files.
